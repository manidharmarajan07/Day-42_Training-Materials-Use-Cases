# Healthcare: Patient, Clinical & Care Coordination Operations

## Centre of Gravity

Privacy, consent, identity resolution, clinical safety, AI provenance, and audit reconstruction.

## Enterprise Context

This repository represents a brownfield estate built over several engineering generations: legacy scripts and files, partially modernized APIs, operational portals, synthetic enterprise data, and newly introduced AI assistance. The design is intentionally credible rather than clean. Participants must infer reality by reading code, data, configuration, tests, docs, and operational artifacts.

## Business Flows

- Patient registration to consent verification
- Document intake to clinical summarization
- Referral triage to human review
- Care-plan follow-up to audit evidence

## Core Personas and Identities

- `patient`
- `clinician`
- `nurse`
- `pharmacist`
- `care_coordinator`
- `receptionist`
- `auditor`
- `integration_service`
- `ai_assistant`

## Domain Data Model

- `patients`: patient_id, mrn, facility_id, full_name, dob, sex, phone, consent_status, primary_condition, risk_band, duplicate_flag, last_seen_at
- `encounters`: encounter_id, patient_id, clinician_id, department, encounter_type, triage_level, diagnosis_code, status, started_at, closed_at, ai_summary_used
- `documents`: document_id, patient_id, doc_type, source, contains_phi, trust_level, ocr_status, injection_marker, received_at, retention_class
- `consents`: consent_id, patient_id, purpose, status, captured_by, expires_at, source_system, facility_scope
- `appointments`: appointment_id, patient_id, facility_id, specialty, scheduled_at, status, referral_source, no_show_risk
- `ai_invocations`: ai_call_id, patient_id, use_case, model, model_version, prompt_template, retrieval_set_id, token_count, guardrail_status, human_approval_id

## What Makes This a Strong Brownfield Candidate

- multiple teams appear to own overlapping capabilities
- legacy and modern paths disagree on semantics
- AI is assistive but insufficiently governed
- audit evidence exists but cannot yet reconstruct the full decision chain
- authorization is role-centric and needs contextual policy
- reliability behavior is uneven across synchronous, batch, and event paths
- cost and token usage are visible in fragments but not tied to business outcomes
