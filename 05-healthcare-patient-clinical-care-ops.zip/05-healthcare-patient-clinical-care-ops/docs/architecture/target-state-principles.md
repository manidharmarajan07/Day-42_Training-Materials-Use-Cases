# Target-State Principles

- Preserve business continuity while modernizing incrementally.
- Treat AI as a governed subsystem, not a magic endpoint.
- Use policy-as-code for high-risk decisions.
- Generate evidence as a by-product of delivery.
- Make failure modes explicit, observable, and testable.
- Connect cost to business outcomes.

## Domain-Specific North Star

Privacy, consent, identity resolution, clinical safety, AI provenance, and audit reconstruction.
