# Current-State Architecture

This repo has three engineering generations coexisting:

1. Legacy batch/files/scripts under `legacy/` and `etl/`
2. Modernizing FastAPI services under `apps/api/`
3. New AI-assisted capabilities under `apps/api/services/ai_gateway.py`

## AI Capabilities

- Clinical Operations Copilot
- Document Intelligence
- Referral Triage

## Centre of Gravity

Privacy + identity + AI safety + auditability
