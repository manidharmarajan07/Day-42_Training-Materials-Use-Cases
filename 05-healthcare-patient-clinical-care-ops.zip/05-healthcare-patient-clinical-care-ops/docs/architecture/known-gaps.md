# Known Gaps Hidden in Plain Sight

- duplicate_patient_identity
- phi_in_debug_logs
- missing_consent_checks
- stale_guideline_retrieval
- prompt_injection_in_uploaded_pdf
- overbroad_clinician_access

Not every issue is directly labelled in code. Participants must corroborate via code, data, tests, docs, and runtime behavior.
