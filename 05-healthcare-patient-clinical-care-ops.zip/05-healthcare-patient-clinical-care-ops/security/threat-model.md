# Threat Model Starter

## Known Brownfield Concerns

- duplicate_patient_identity
- phi_in_debug_logs
- missing_consent_checks
- stale_guideline_retrieval
- prompt_injection_in_uploaded_pdf
- overbroad_clinician_access

## Expected Participant Work

Map these to STRIDE/MAESTRO, add controls, tests, and evidence.
