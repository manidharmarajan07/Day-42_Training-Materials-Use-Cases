export class OperationsComponent {
  title = 'Energy & Utilities: Metering, Outage & Field Service Operations';
  // Brownfield issue: UI trusts backend decisions and has no field-level masking.
  visibleColumns = ['id', 'status', 'risk_score', 'owner', 'last_updated'];
}
