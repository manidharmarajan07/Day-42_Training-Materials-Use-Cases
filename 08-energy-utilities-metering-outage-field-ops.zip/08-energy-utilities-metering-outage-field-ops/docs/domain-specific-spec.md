# Energy & Utilities: Metering, Outage & Field Service Operations

## Centre of Gravity

Critical-service reliability, OT/IT boundaries, telemetry integrity, bounded AI agency, and regulatory evidence.

## Enterprise Context

This repository represents a brownfield estate built over several engineering generations: legacy scripts and files, partially modernized APIs, operational portals, synthetic enterprise data, and newly introduced AI assistance. The design is intentionally credible rather than clean. Participants must infer reality by reading code, data, configuration, tests, docs, and operational artifacts.

## Business Flows

- Meter telemetry to validation
- Anomaly detection to outage incident
- Crew dispatch to restoration
- Regulatory evidence reconstruction

## Core Personas and Identities

- `control_center_operator`
- `grid_engineer`
- `field_crew`
- `contractor`
- `customer_support`
- `analytics_service`
- `ai_copilot`
- `regulator_readonly`

## Domain Data Model

- `meters`: meter_id, customer_id, feeder_id, transformer_id, meter_generation, install_date, comm_status, last_read_at, estimated_reading_flag, swap_suspected
- `assets`: asset_id, asset_type, substation_id, feeder_id, age_years, criticality, maintenance_due, condition_score, owner_team, ot_zone
- `telemetry`: telemetry_id, meter_id, asset_id, reading_time, voltage, current_amp, power_factor, quality_flag, source_gateway, late_arrival_flag
- `outages`: outage_id, feeder_id, detected_at, status, affected_customers, estimated_restore_at, false_positive_risk, weather_related, regulatory_reportable
- `work_orders`: work_order_id, outage_id, crew_id, priority, dispatch_status, safety_clearance, started_at, completed_at, contractor_used
- `ai_invocations`: ai_call_id, outage_id, use_case, model, telemetry_window, token_count, recommendation, safety_gate, operator_approval

## What Makes This a Strong Brownfield Candidate

- multiple teams appear to own overlapping capabilities
- legacy and modern paths disagree on semantics
- AI is assistive but insufficiently governed
- audit evidence exists but cannot yet reconstruct the full decision chain
- authorization is role-centric and needs contextual policy
- reliability behavior is uneven across synchronous, batch, and event paths
- cost and token usage are visible in fragments but not tied to business outcomes
