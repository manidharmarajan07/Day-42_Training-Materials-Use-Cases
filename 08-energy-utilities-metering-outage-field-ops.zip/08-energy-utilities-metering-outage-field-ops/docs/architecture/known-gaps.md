# Known Gaps Hidden in Plain Sight

- meter_id_swaps
- estimated_actual_mixed
- stale_asset_hierarchy
- unsafe_ai_operational_action
- contractor_overprivilege
- telemetry_gap

Not every issue is directly labelled in code. Participants must corroborate via code, data, tests, docs, and runtime behavior.
