# Synthetic Data

Domain: Energy & Utilities: Metering, Outage & Field Service Operations

This data is fully synthetic and designed for realistic workshop discovery. It includes enough volume for baseline profiling, ETL validation, event-correlation exercises, observability design, AI FinOps analysis, and data-quality remediation.

## Included Files

- `synthetic/meters.csv`: 354 rows
- `synthetic/assets.csv`: 354 rows
- `synthetic/telemetry.csv`: 354 rows
- `synthetic/outages.csv`: 354 rows
- `synthetic/work_orders.csv`: 354 rows
- `synthetic/ai_invocations.csv`: 354 rows
- `synthetic/events.jsonl`: 3000 operational events

## Deliberate Data Problems

- duplicate identifiers and duplicate business events
- blank mandatory fields
- stale or impossible timestamps
- out-of-range scores
- untrusted text payloads suitable for prompt-injection testing
- missing correlation identifiers
- mixed legacy and modern source-system semantics
