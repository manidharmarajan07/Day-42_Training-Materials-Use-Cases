# Threat Model Starter

## Known Brownfield Concerns

- meter_id_swaps
- estimated_actual_mixed
- stale_asset_hierarchy
- unsafe_ai_operational_action
- contractor_overprivilege
- telemetry_gap

## Expected Participant Work

Map these to STRIDE/MAESTRO, add controls, tests, and evidence.
